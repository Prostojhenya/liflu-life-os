import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig, loadEnv} from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig(({mode}) => {
  const env = loadEnv(mode, '.', '');
  return {
    plugins: [
      react(), 
      tailwindcss(),
      VitePWA({
        registerType: 'autoUpdate',
        manifest: {
          name: 'Liflu - Life OS',
          short_name: 'Liflu',
          description: 'Your personal Life OS for tasks, habits, and goals.',
          theme_color: '#0b0416',
          background_color: '#0b0416',
          display: 'standalone',
          orientation: 'portrait',
          icons: []
        }
      })
    ],
    define: {
      'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY),
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './src'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
    },
    build: {
      rollupOptions: {
        output: {
          manualChunks: {
            'firebase': ['firebase/app', 'firebase/auth', 'firebase/firestore'],
            'react-vendor': ['react', 'react-dom'],
            'charts': ['recharts'],
          }
        }
      },
      chunkSizeWarningLimit: 1000,
    },
  };
});
